import json
import boto3
import pdfkit
from jinja2 import Template

s3 = boto3.client('s3')
cloudwatch = boto3.client('cloudwatch')
ses = boto3.client('ses')

def transform_dashboard_to_html(dashboard_data):
    # Define your Jinja2 template for HTML formatting
    html_template = """
    <html>
    <head><title>CloudWatch Dashboard Report</title></head>
    <body>
    <h1>CloudWatch Dashboard Report</h1>
    {{ dashboard_data }}
    </body>
    </html>
    """

    # Render the HTML template with the dashboard data
    template = Template(html_template)
    html_content = template.render(dashboard_data=json.dumps(dashboard_data, indent=2))

    return html_content

def send_email_with_attachment(pdf_content):
    # Specify your SES sender and recipient email addresses
    sender_email = 'tgrahesh@gmail.com'
    recipient_email = 'tgrahesh@gmail.com'
    
    # Create a PDF from the HTML content
    pdf = pdfkit.from_string(pdf_content, False)
    
    # Upload the PDF to an S3 bucket
    s3.put_object(Bucket='LambdaFunction-s3', Key='Testreport.pdf', Body=pdf)
    
    # Send the email with the PDF attachment
    ses.send_email(
        Source='tgrahesh@gmail.com',
        Destination={'ToAddresses': 'tgrahesh@gmail.com'},
        Message={
            'Subject': {'Data': 'CloudWatch Dashboard Report'},
            'Body': {
                'Text': {'Data': 'Please find the CloudWatch Dashboard report attached.'},
                'Html': {'Data': '<p>Please find the CloudWatch Dashboard report attached.</p>'}
            }
        },
        ReplyToAddresses='tgrahesh@gmail.com',
        Attachments=[{
            'FileName': 'Testreport.pdf',
            'Data': pdf
        }]
    )

def lambda_handler(event, context):
    # Get the custom CloudWatch dashboard data
    dashboard_data = cloudwatch.get_dashboard(DashboardName='Testreport.pdf')

    # Transform dashboard data into HTML content
    html_content = transform_dashboard_to_html(dashboard_data)

    # Generate a PDF report from HTML
    pdf = pdfkit.from_string(html_content, False)

    # Send an email with the PDF attachment
    send_email_with_attachment(html_content)

    return {
        'statusCode': 200,
        'body': json.dumps('Email sent successfully!')
    }

